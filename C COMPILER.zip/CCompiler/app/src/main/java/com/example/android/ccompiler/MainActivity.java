package com.example.android.ccompiler;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button runButton;
    EditText codeInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        runButton = (Button)findViewById(R.id.run_button);
        codeInput = (EditText)findViewById(R.id.program);
        runButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),OutputActivity.class);
                String code = codeInput.getText().toString();
                Log.d("Code",code);
                Bundle extra = new Bundle();
                extra.putString("code",code);
                intent.putExtras(extra);
                startActivity(intent);
            }
        });
    }
}
