package com.example.android.ccompiler;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.ccompiler.NetworkUtils.ConnectNetwork;
import com.example.android.ccompiler.NetworkUtils.NetworkContract;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class OutputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String code = null;
        //String outputPrint = "Something Went Wrong";
        //TextView output;
        Bundle extra;
        setContentView(R.layout.activity_output);
        Intent intent = this.getIntent();
        TextView output = (TextView)findViewById(R.id.program_output);

        try {
            extra = intent.getExtras();
            code = (String) extra.get("code");
            Log.d("Code Value", "onCreate: "+code);

        }
        catch (StringIndexOutOfBoundsException e){
            e.printStackTrace();
        }
        catch (NullPointerException e){
            e.printStackTrace();
        }
        if(code!=null){
            ConnectNetwork network = new ConnectNetwork();
            ArrayList<String> arr_field = new ArrayList<>(),
                    arr_values = new ArrayList<>();

            arr_field.add(NetworkContract.post_client_secret);
            arr_field.add(NetworkContract.post_code);
            arr_field.add(NetworkContract.post_lang);

            arr_values.add(NetworkContract.client_secret);
            arr_values.add(code);
            arr_values.add("C");

            String result = network.postData(arr_field,arr_values);
            if(result!=null){
                if(result.isEmpty())
                    Toast.makeText(getApplicationContext(),"Something went wrong !",Toast.LENGTH_SHORT).show();
                else {

                    /*try {
                        JSONObject object = new JSONObject(result);

                        JSONObject run_status = object.getJSONObject("run_status");
                        String status_detail = run_status.getString("status_detail");
                        Toast.makeText(getApplicationContext(),status_detail,Toast.LENGTH_LONG).show();
                        if(status_detail!="NA"){
                            Toast.makeText(getApplicationContext(),status_detail,Toast.LENGTH_LONG).show();
                        }
                        else{
                            String out = run_status.getString("output");
                            output.setText(out);
                        }

                    } catch (JSONException e) {
                       e.printStackTrace();

                    }*/
                    output.setText(result);
                }
            }
            else
                Toast.makeText(getApplicationContext(),"Connection Failed",Toast.LENGTH_SHORT).show();
        }
    }
}
