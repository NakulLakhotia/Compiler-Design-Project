package com.example.android.ccompiler.NetworkUtils;

/**
 * Created by root on 18/9/17.
 */

public class NetworkContract {


    // Network Connectivity
    public static final int READ_TIMEOUT = 15000;
    public static final int CONNECTION_TIMEOUT = 15000;
    public static final String REQUEST_GET_METHOD = "GET";
    public static final String REQUEST_POST_METHOD = "POST";
    public static final String server_address = "http://api.hackerearth.com/code/run/";
    public static final String user_id = "f1d0ec3cb8cd0a640eb5e1cf9306a7ab15cee5b96dc7.api.hackerearth.com";
    public static final String client_secret = "a480a050afefdcaac707432cc509a6cb06e970ec";



    // API

    public static final String post_client_secret = "client_secret";
    public static final String post_lang = "lang";
    public static final String post_code = "source";



}
