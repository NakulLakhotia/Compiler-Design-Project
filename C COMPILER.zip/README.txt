1)DOWNLOAD THE ANDROID STUDIO IN YOUR LAPTOP/PC

2)EXTRACT THE ZIP FILE CONTAINING FOLDER 'CCompiler' TO 'AndroidStudioProjects'.

3)THE PATH FOR 'AndroidStudioProjects' IS

"C:\Users\<YOUR ACCOUNT WHERE YOU INSTALLED THE ANDROID STUDIO>\AndroidStudioProjects\C"

4)OPEN THE ANDROID STUDIO.THEN GO TO
FILE-> OPEN-> SELECT 'CCompiler' AND CLICK OK.

5)'OPEN PROJECT' DIALOG BOX OPENS -> SELECT 'New Window'

6)THE PROJECT OPENS IN A NEW WINDOW
***********************************************************************************************************

TO VIEW THE ACTIVITY(XML FILES).

1)ON THE LEFT OF THE SCREEN CLICK ON 'CCompiler'
2)CLICK ON 'app'
3)app->src->main->res->layout
4)Double Click on activity_main.xml 
5)Double Click on activity_output.xml
6)To view the xml code click on 'Text' button beside the 'Design' button at the bottom

***********************************************************************************************************
TO VIEW THE ACTIVITY(JAVA FILES).

1)ON THE LEFT OF THE SCREEN CLICK ON 'CCompiler'
2)CLICK ON 'app'
3)app->src->main->java->
4)Double Click on MainActivity(the java code opens up)
5)Double Click on OutputActivity(the java code opens up)

************************************************************************************************************
TO VIEW THE NETWORK CONNECTIVITY(JAVA FILES).

1)ON THE LEFT OF THE SCREEN CLICK ON 'CCompiler'
2)CLICK ON 'app'
3)app->src->main->java->NetworkUtils
4)Double Click on ConnectNetwork(the java code opens up)
5)Double Click on NetworkContract(the java code opens up)

************************************************************************************************************
TO BUILD AN APK

1)ON THE TOP CLICK ON 'Build'
2)Build->Build APK(s)
3)A MESSAGE BOX ON THE BOTTOM RIGHT CORNER APPEARS.
4)SELECT 'locate' option'

************************************************************************************************************
TO RUN THE APPLICATION(INTERNET CONNECTION IS REQUIRED)

1)MAKE SURE THE DEVELOPER OPTIONS IS ENABLED IN YOUR PHONE.
2)CONNECT YOUR ANDORID PHONE TO THE LAPTOP THROUGH A USB CABLE
3)TO CHECK IF DEVELOPER OPTIONS IS ENABLED OR NOT.
4)GO TO PHONE SETTINGS
SETTINGS->ABOUT PHONE->SOFWARE INFORMATION
TAP ON 'BUILD NUMBER' UNTIL YOU SEE an on-screen prompt stating that you�re a developer.
5)ENABLE THE DEVELOPER OTPIONS IF NOT ENABLED
6)SCROLL DOWN AND ENABLE USB DEBUGGING
7)ALSO ENABLE 'Install via USB'
8)GO TO ANDROID STUDIO AND OPEN THE PROJECT WHICH YOU WISH TO RUN(make sure phone is connected to laptop)
9)ON THE TOP CLICK ON 'Run'
Run->Run app->Select your device(automatically detected) and click on 'OK'
10) Click on the second option i.e 'Run without installation'
11)WAIT FOR THE APP TO OPEN ON YOUR PHONE.

